<?php
    $num1 = 0; //Váriaveis globais (código todo utiliza)
    $num2 = 0;

   function somar($num1,$num2){
        return (int)$num1 + (int)$num2;
   }//fim do somar 

    function subtrair($num1,$num2){
        return $num1-$num2;
    }//fim do subtrair 

    function multiplicar($num1,$num2){
        return $num1*$num2;
    }//fim do multiplicar

  function dividir($num1,$num2){
        if ($num2==0){ 
         return "impossível dividir por 0";
   }else{
         return $num1/$num2; 
   }
  }//fim do dividir
    function potencia ($num1,$num2){
        if($num2 < 0 ){
            return "impossível calcular a potência de expoente negativo";
     }else{
         return pow($num1,$num2);
     }
    }//fim do método

    function raiz($num1){
        if($num1 < 0){
            return "impossível calcular a raiz de número negativo";
        }else{
          return sqrt($num1);
    }
    }//fim da raiz 

    function tabuada($num1){
           $i = 0;
          $resultado =""; 
     for($i; $i < 11; $i++){
           $resultado = "<br>".$num1." * ".$i."=".($num1*$i);

    }//fim do for
        return $resultado;
    }//fim do resultado 

    function areaRetangulo ($base,$altura){
        if(($base <= 0) || ($altura <= 0)){
            return "impossível calcular a área";
        }else{
            return $base* $altura;
        }
        }//fim do método 

        function delta ($a,$b,$c){
            //delta= b² - 4 * a * c
            $d = pow($b,2) - 4 * $a * $c;
            if($d < 0){
                return -1;
            }else{
                return $d;
            }
        }//fim do método 

        function X1 ($a,$b,$c){
            $d = delta ($a,$b,$c);
            if ($d == -1){
                return "impossível calcular X1, delta negativo";
            }else{
                return(-$b + sqrt($d))/(2*$a);
            }
            
        }//fim do X1
        
        function X2 ($a,$b,$c){
            $d = delta ($a,$b,$c);
            if ($d == -1){
                return "impossível calcular X2, delta negativo";
            }else{
                return (-$b - sqrt($d))/(2*$a);
            }
          
        }//fim do X2

        function parImpar($num){
            if ($num % 2 ==0){
                return "Par";
            }else{
                return "Impar";
            }
        }

       function maiorIdade ($idade){
        if ($idade < 18){
            return "Menor de idade";
        }else{
            return "Maior de idade ";
        }
       }//fim so maioridade


       function dobro ($num){
          return ($num * 2 );
       }//fim do método 

       function celciusFahrenheit ($celcius){
         return ($celcius * 1.8)+32;
       }//fim do método 

       function buscarMaior ($num1,$num2,$num3){
        if ($num1 > $num2 && $num2 > $num3){
            return $num1;
        }else if ($num2 > $num1 && $num2 > $num3){
            return $num2;
        }else{
            return $num3;
        }
       }

       function positivoNegativo ($num){
        if ($num > 0){
            return "Positivo";
     }else if ($num < 0 ){
            return  "Negativo ";
    }else if ($num = 0 ){
            return "Zero";
        }
        }//fim do método 

        function soma ($num){
            $i = 1;
            $soma = 0;
       for ($i; $i <= $num; $i++){
        $soma += $i;
       } 
       return $soma;
        }//fim do resultado

        //substr("")
        function primo ($num){
            if ($num <2 ){
                  return "Não é primo!";
            }
            for($i = 2; $i <= sqrt ($num); $i++){
                if ($num % $i == 0 ){
                    return "Não é primo";
                }
            }
            return "Primo";
            }//fim do método 


           
            function polindromo ($palavra){
               if($palavra == strrev ($palavra)){
                 return "Palíndromo!";      
               }else{
                 return "Não é palíndromo";
               }
            }
            

            function fatorial ($num){
                $i = $num- 1;
                 for($i; $i>= 1; $i--){
                $num = $num * $i;
                }
                  return $num;
            }


            function paresListas ($num){
                $i = 1;
                $pares = "";
                for ($i; $i <= $num; $i++){
                    if ($i % 2 == 0){
                        $pares .= "<br>" .$i;
                    }
                }//fim do for 
              return $pares; 
            }//fim do método 

          
            //strlen("")
        function ContarVogais ($palavra){
         $tamanho= strlen($palavra); //tamanho da palavra 
          $i = 0; 
          $letra = "";
           $contador = 0;
          for ($i; $i < $tamanho; $i++){
            $letra = substr($palavra,$i,1);
            switch ($letra){
                case 'A' || 'a':
                    $contador++; 
                    break; 
                    case 'a':
                        $contador++; 
                        break; 
                    case 'E': 
                        $contador++; 
                        break; 
                         case 'e':
                            $contador++; 
                            break; 
                         case 'I':
                                $contador++; 
                                break; 
                        case  'i':
                            $contador++; 
                            break; 
                         case 'O':
                                $contador++; 
                                break; 
                         case 'o':
                                    $contador++; 
                                    break; 
                         case 'U':
                                    $contador++; 
                                    break;
                        case 'u':
                                        $contador++; 
                                        break; 
                                
            }
          }//fim do for 
          return $contador;
        }//fim do método 
       
        function mostrarPrimos ($num){
            $nmuPrimos= "";
             $i = 1;
             for ($i; $i <= $num; $i++){
         if (primo($i)!= "Não é primo"){
           $numPrimos = "<br>" .$i; 
           }
        }
          return $numPrimos;
        }//fim do mostrar
        
       function data ($month,$day,$year){
        if (checkdate($month,$day,$year)){
            return "Data Válida!";
        }else{
            return "Data inválida";
        }
       }//fim do método 

       function media ($nota1,$nota2,$nota3,$nota4,$nota5){    
         $media = 0; 
         $media = ($nota1+ $nota2+ $nota3+$nota4+$nota5)/5;
         return $media;

       }

       function divisores($num){
        $i = 1; 
        $divisor= ""; 
        for ($i; $i < $num;$i++){
        if ($num % $i ==0){
            $divisor = "<br>" .$i;
        }
       }
       return $divisor;
    }

        function contarPalavrs ($texto){
            $contar = str_word_count (texto,0);
            return $contar; 
        }

        function fibonacci ($num){
            $i = 0; 
            $fib0= 0;
            $fib1= 1;
            $fib2 = 0;
             $result = $fib0. "<br>" .$fib1; 
            for ($i; $i <= $num; $i++){
                $fib2= $fib0+ $fib1; 
                $result .= "<br>" .$fib2;
                $fib0= $fib1; 
                $fib1;
            }
        }

        function idade ($dia, $mes, $ano){
            return ($ano * 365) + ($mes * 30) + $dia; 
        }//fim do método 

 
   //resultados 
     echo "<br>A soma dos números é:".somar(5,8);
     echo "<br>A subtração dos números é:".subtrair(9,15);
     echo "<br>A multiplicação dos números é:".multiplicar(10,8);
     echo "<br>A divisão dos números é:".dividir(3,1);
     echo"<br>A potência dos números é:".potencia(10,2);
     echo"<br>A raiz do número é:" .raiz(10);
     echo "<br>A tabuada do número informado é:" .tabuada(8);
     echo "<br>A área do retangulo é:" .areaRetangulo(5,6);
     echo "<br>A soma de delta é:" .delta(5,9,6);
     echo "<br>O X1 é:" .X1(-8,5,9);
     echo "<br>O X2 é:" .X2(-8,5,9);
     echo "<br>Par ou impar ?" .parImpar(5);
     echo "<br>Maior ou menor de idade? " .maiorIdade(21);
     echo "<br>O dobro do número é" .dobro(100);
     echo "<br>Temperatura em fFahrenheit" .celciusFahrenheit(25);
     echo "<br>O maior dos três é: " .buscarMaior (10,4,60);
     echo "<br>O número é: " .positivoNegativo(-1);
     echo "<br>A soma dos números informado é:" .soma(50);
     echo "<br>O número informado é:  " .primo(7);
     echo "<br>A palavra é: "  .polindromo("ana");
     echo "<br>O fatorial é: " .fatorial(7);
     echo "<br>Os números pares são: " .paresListas(30);
     echo "<br>Vogais na palavra digitadas: " .ContarVogais("Allan");
     echo "<br>Números primos:" .mostrarPrimos(10);
     echo "<br>" .data ('02','29','1996');
     echo "<br>A média total é" .media(12,2,88,4,6);
     echo "<br>Os divisores do número informado é:" .divisores(30);
     echo "<br>A soma da sua idade é: " .idade(30)
?> 