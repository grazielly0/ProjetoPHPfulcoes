<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <title>Página Inicial</title>
</head>
<body>
 <butonn><a href="exercício1.php">Exerício01</a></butonn><br>
 <butonn><a href= "exercício2.php">Exerício02</a></butonn><br>
 <butonn><a href= "exercício3.php">Exerício03</a></butonn><br>
 <butonn><a href= "exercício4.php">Exerício04</a></butonn><br>
 <butonn><a href= "exercício5.php">Exerício05</a></butonn><br>
 <butonn><a href= "exercício6.php">Exerício06</a></butonn><br>
 <butonn><a href= "exercício7.php">Exerício07</a></butonn><br>
 <butonn><a href= "exercício8.php">Exerício08</a></butonn><br>
 <butonn><a href= "exercício9.php">Exerício09</a></butonn><br>
 <butonn><a href= "exercício10.php">Exerício10</a></butonn><br>
 <butonn><a href= "exercício11.php">Exerício11</a></butonn><br>
 <butonn><a href= "exercício12.php">Exerício12</a></butonn><br>
 <butonn><a href= "exercício13.php">Exerício13</a></butonn><br>
 <butonn><a href= "exercício14.php">Exerício14</a></butonn><br>
 <butonn><a href= "exercício15.php">Exerício15</a></butonn><br>
 <butonn><a href= "exercício16.php">Exerício16</a></butonn><br>
 <butonn><a href= "exercício17.php">Exerício17</a></butonn><br>
 <butonn><a href= "exercício18.php">Exerício18</a></butonn><br>
 <butonn><a href= "exercício19.php">Exerício19</a></butonn><br>
 <butonn><a href= "exercício20.php">Exerício20</a></butonn><br>
 <butonn><a href= "exercício21.php">Exerício21</a></butonn><br>
 <butonn><a href= "exercício22.php">Exerício22</a></butonn><br>
 <butonn><a href= "exercício23.php">Exerício23</a></butonn><br>
 <butonn><a href= "exercício24.php">Exerício24</a></butonn><br>
 <butonn><a href= "exercício25.php">Exerício25</a></butonn><br>
 <butonn><a href= "exercício26.php">Exerício26</a></butonn><br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
 <butonn><a href="exercícios1.php">Exerício01</a></butonn><br>
 <butonn><a href= "exercícios2.php">Exerício02</a></butonn><br>
 <butonn><a href= "exercícios3.php">Exerício03</a></butonn><br>
 <butonn><a href= "exercícios4.php">Exerício04</a></butonn><br>
 <butonn><a href= "exercícios5.php">Exerício05</a></butonn><br>
 <butonn><a href= "exercícios6.php">Exerício06</a></butonn><br>
 <butonn><a href= "exercícios7.php">Exerício07</a></butonn><br>
 <butonn><a href= "exercícios8.php">Exerício08</a></butonn><br>
 <butonn><a href= "exercícios9.php">Exerício09</a></butonn><br>
 <butonn><a href= "exercícios10.php">Exerício10</a></butonn><br>
 <butonn><a href= "exercícios11.php">Exerício11</a></butonn><br>
 <butonn><a href= "exercícios12.php">Exerício12</a></butonn><br>
 <butonn><a href= "exercícios13.php">Exerício13</a></butonn><br>
 <butonn><a href= "exercícios14.php">Exerício14</a></butonn><br>
 <butonn><a href= "exercícios15.php">Exerício15</a></butonn><br>
 <butonn><a href= "exercícios16.php">Exerício16</a></butonn><br>
 <butonn><a href= "exercícios17.php">Exerício17</a></butonn><br>
 <butonn><a href= "exercícios18.php">Exerício18</a></butonn><br>
 <butonn><a href= "exercícios19.php">Exerício19</a></butonn><br>
 <butonn><a href= "exercícios20.php">Exerício20</a></butonn><br>
 <butonn><a href= "exercícios21.php">Exerício21</a></butonn><br>
 <butonn><a href= "exercícios22.php">Exerício22</a></butonn><br>
 <butonn><a href= "exercícios23.php">Exerício23</a></butonn><br>
 <butonn><a href= "exercícios24.php">Exerício24</a></butonn><br>
 <butonn><a href= "exercícios25.php">Exerício25</a></butonn><br>
 <butonn><a href= "exercícios26.php">Exerício26</a></butonn><br>
 <butonn><a href= "exercícios27.php">Exerício27</a></butonn><br>
 <butonn><a href= "exercícios28.php">Exerício28</a></butonn><br>
 </body>
</html>