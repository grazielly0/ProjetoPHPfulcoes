<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXERCÍCIO22</title>
</head>
<body>
     <?php
      include 'fulcoes.php';
       $nome="";//instanciando
      
      ?>
     
     <h1>Exerício 22</h1>
     
    <form method= "POST">
        <label>Insira um Nome:</label>
        <input type="text" id= "nome" name= "nome"><br><br>


         <button>Calcular
            <?php
             
            $nome= $_POST ['nome'];
            
            ?>

         </button><br><br>
         <textArea rows= "40" cols= "40" readonly fixed>

         <?php
         if ($nome==""){
            echo "Preencha os campos";
         }else{
            echo "Vogais na palavras digitadas:" .contarVogais($nome);
         }
         ?> 
         </textArea>