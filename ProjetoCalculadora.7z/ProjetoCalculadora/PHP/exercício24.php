<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EXERCÍCIO24</title>
</head>
<body>
     <?php
      include 'fulcoes.php';
       $date="";//instanciando
      
      ?>
     
     <h1>Exerício 24</h1>
     
    <form method= "POST">
        <label>Insira uma data:</label>
        <input type="text" id= "date" name= "date"><br><br>


         <button>Calcular
            <?php
             
            $date= $_POST ['data'];
            
            ?>

         </button><br><br>
         <textArea rows= "40" cols= "40" readonly fixed>

         <?php
         if ($date==""){
            echo "Preencha os campos";
         }else{
            echo "." .data ($date);
         }
        
         ?> 
         </textArea>
    </form>
</body>
</html>